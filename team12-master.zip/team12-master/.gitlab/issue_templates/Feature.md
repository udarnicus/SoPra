> Als *Rolle* möchte ich *Ziel/Wunsch*, um *Nutzen*.

## Ausführlichere Beschreibung

*bei Bedarf*

## Akzeptanztests
- Akzeptanztests: 
    - *TODO (Beschreibung von Testfällen die das erwartete Verhalten des gesamten Features überprüfen.)*
    - *TODO*
    - *TODO*

## Meta
- Aufwandsschätzung: [XS, S, M, L, XL]
- Enthaltene Implementable Stories:
    - [Implementable Story 1](#)
    - [Implementable Story 2](#)
    - [Implementable Story 3](#)
