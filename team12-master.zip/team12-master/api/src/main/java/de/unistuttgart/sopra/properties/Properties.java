package de.unistuttgart.sopra.properties;

public final class Properties {

    private Properties() {
        // restrict instantiation
    }


    public static final String LINK = "bilbao.informatik.uni-stuttgart.de/team12";
    public static final String USERNAME = "team12";
    public static final String PASSWORD = "e345c973d6f4d770";

    /*public static final String LINK = "192.168.0.202:3306/team12";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "incorrect";*/
}