<template>
    <vs-row>
        <vs-col vs-lg="3" vs-sm="6" vs-xs="12">
            <vs-card actionable >
                <div slot="header">
                  <h3>
                    Hello world !
                  </h3>
                </div>
                <div slot="media">
                  <img src="@/assets/images/big/img5.jpg">
                </div>
                <div class="mb-2">
                <h6 class="mb-2">23<sup>rd</sup> oct 2020</h6>    
                Lorem ipsum dolor sit amet, consectetur ipsum dolor sit amet, consectetur ipsum dolor sit amet, consectetur adipiscing elit</div>
                <vs-button color="warning" type="filled">Read More</vs-button>
            </vs-card>
        </vs-col>
        <vs-col vs-lg="3" vs-sm="6" vs-xs="12">
            <vs-card actionable >
                <div slot="header">
                  <h3>
                    Hello world !
                  </h3>
                </div>
                <div slot="media">
                  <img src="@/assets/images/big/img4.jpg">
                </div>
                <div class="mb-2">
                <h6 class="mb-2">23<sup>rd</sup> oct 2020</h6>    
                Lorem ipsum dolor sit amet, consectetur ipsum dolor sit amet, consectetur ipsum dolor sit amet, consectetur adipiscing elit</div>
                <vs-button color="danger" type="filled">Read More</vs-button>
            </vs-card>
        </vs-col>
        <vs-col vs-lg="3" vs-sm="6" vs-xs="12">
            <vs-card actionable >
                <div slot="header">
                  <h3>
                    Hello world !
                  </h3>
                </div>
                <div slot="media">
                  <img src="@/assets/images/big/img3.jpg">
                </div>
                <div class="mb-2">
                <h6 class="mb-2">23<sup>rd</sup> oct 2020</h6>    
                Lorem ipsum dolor sit amet, consectetur ipsum dolor sit amet, consectetur ipsum dolor sit amet, consectetur adipiscing elit</div>
                <vs-button color="primary" type="filled">Read More</vs-button>
            </vs-card>
        </vs-col>
        <vs-col vs-lg="3" vs-sm="6" vs-xs="12">
            <vs-card actionable >
                <div slot="header">
                  <h3>
                    Hello world !
                  </h3>
                </div>
                <div slot="media">
                  <img src="@/assets/images/big/img1.jpg">
                </div>
                <div class="mb-2">
                <h6 class="mb-2">23<sup>rd</sup> oct 2020</h6>    
                Lorem ipsum dolor sit amet, consectetur ipsum dolor sit amet, consectetur ipsum dolor sit amet, consectetur adipiscing elit</div>
                <vs-button color="success" type="filled">Read More</vs-button>
            </vs-card>
        </vs-col>
    </vs-row>    
</template>
<script>
export default {
    name: "Blogs"
}
</script>