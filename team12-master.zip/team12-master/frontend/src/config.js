export default {
    'apiKey' : "loFDNuqh3KfNWTOZhzYAz0pty8EORUuK",
    'apiKeyWeather': "d03f492cd4b8de759fc80d55392e5013",
    "apiBaseUrl": "http://localhost:8080/"
}