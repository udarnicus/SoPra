import VueWeatherWidget from "./VueWeatherWidget.vue";

export default VueWeatherWidget;
