	export default [
		{
			url:"/home",
			name:"Home",
			icon:"home"
		},
		{
			url :"/projectList",
			name:"Projects",
			icon:"list"
		},
		{
			url :"/employeeList",
			name: "Employees",
			icon: "folder_shared"
		},
		{
			url: "/clientlist",
			name: "Clients",
			icon:"people"  /*error_outline*/
		},
		{
			url:"/timeRegistration",
			name:"Time Registration",
			icon:"watch_later"
		},
		/*{
			url:"/CSV-Import",
			name:"CSV Import",
			icon:"get_app"
		},*/

]