module.exports = {
  publicPath: '/'
}
